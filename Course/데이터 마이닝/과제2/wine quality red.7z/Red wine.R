#install.packages("class")
library(class)

red <- read.csv("winequality-red.csv", sep=";")
n <- nrow(red)

red$quality <- ifelse(red$quality > 5, 1, 0)
redx <- red[1:11]
redy <- red[,12]

summary(red)

barplot(table(redy), xlab = "Quality", ylab = "Freq")

###############################################################3
#KNN

fit = knn(train=redx,test=redx,cl=redy, k=5) 
#Accepting numerical variables
#K=5


### Prediction

yhat=fit
ctable = table(redy, yhat, dnn=c("Actual", "Predicted")); ctable #classification table


### Errors

miss.err = 1-sum(diag(ctable))/sum(ctable); miss.err # Misclassification Rate
pred.acc = 1 - miss.err; pred.acc #Prediction Accuracy
diag(ctable)[2]/apply(ctable, 1, sum)[2] # Sensitivity
diag(ctable)[1]/apply(ctable, 1, sum)[1] # Specificity


#################################################################################
#LDA QDA


library(MASS)
library(ROCR)


### LDA

fitl = lda(quality~., data=red)
plot(fitl)

## QDA
fitq = qda(quality~., data=red)


### Prediction
#LDA
cutoff = 0.5
pred = predict(fitl, newdata=red)$posterior
yhat = ifelse(pred[,2] > cutoff, 1, 0)
ctable = table(red$quality, yhat, dnn=c("Actual", "Predicted")); ctable #classification table

#QDA
cutoff = 0.5
pred = predict(fitq, newdata=red)$posterior
yhat = ifelse(pred[,2] > cutoff, 1, 0)
ctable = table(red$quality, yhat, dnn=c("Actual", "Predicted")); ctable #classification table


### Errors

miss.err = 1-sum(diag(ctable))/sum(ctable); miss.err # Misclassification Rate
pred.acc = 1 - miss.err; pred.acc #Prediction Accuracy
diag(ctable)[2]/apply(ctable, 1, sum)[2] # Sensitivity
diag(ctable)[1]/apply(ctable, 1, sum)[1] # Specificity


### ROC and AUC

pred2 = predict(fitl, newdata=red)$posterior
pred = prediction(pred2[,2], red$quality)
perf = performance(pred, "tpr","fpr")

par(mfrow=c(1,1))
plot(perf, col = 4, lwd = 2, xlab = "1-Specificity", ylab = "Sensitivity", main = "ROC Curve") #ROC
lines(x = c(0,1), y = c(0,1), col = 2, lty = 2, lwd = 2)
legend(0.6, 0.3, legend = c("LDA/QDA","Random"), col = c(4,2), lty = c(1,2), lwd = 2)

performance(pred, "auc")@y.values #AUC


###########################################
#### Regression

### Model fit

fit = glm(quality ~., data = red, family = binomial(link = "logit"))
summary(fit)


### Model selection

fit2 = step(fit, direction = "both")
fit2$anova
summary(fit2)


### Prediction

fit2.pred = predict(fit2, newdata = red, type = "response") 

cutoff = 0.5
fit2.yhat = ifelse(fit2.pred <= cutoff, 0, 1)

ctable = table(red$quality, fit2.yhat,  dnn = c("Actual", "Predicted"))  
ctable


### Errors

miss.err = 1-sum(diag(ctable))/sum(ctable) # Misclassification Rate
miss.err

pred.acc = 1 - miss.err #Prediction Accuracy
pred.acc  

diag(ctable)[2]/apply(ctable, 1, sum)[2] # Sensitivity
diag(ctable)[1]/apply(ctable, 1, sum)[1] # Specificity


### ROC and AUC


fit.pred = predict(fit, newdata =  red, type = "response") 
pred = prediction(fit.pred, red$quality)

perf = performance(pred, "tpr","fpr")
plot(perf, col = 4, lwd = 2, xlab = "1-Specificity", ylab = "Sensitivity", main = "ROC Curve") #ROC
lines(x = c(0,1), y = c(0,1), col = 2, lty = 2, lwd = 2)
legend(0.6, 0.3, legend = c("Regression","Random"), col = c(4,2), lty = c(1,2), lwd = 2)

performance(pred, "auc")@y.values #AUC


###########################################
# Computing the test error by paritioning



#### Data partition

set.seed(1)
V = 2
n =  NROW(red)
id = sample(1:V, n, prob = c(0.7,0.3), replace = T) # Partitioning 7:3
ii = which(id==1)
red.train = red[ii,]
red.test  = red[-ii,]


#### KNN

c<-matrix(nrow=4, ncol=10)
for(i in 1:10) {
fit = knn(train=red.train[,-12], test=red.test[,-12], cl=red.train[,12], k=i) 


yhat=fit
ctable = table(red.test[,12], yhat, dnn=c("Actual", "Predicted")); ctable #classification table


miss.err = 1-sum(diag(ctable))/sum(ctable); miss.err # Misclassification Rate
pred.acc = 1 - miss.err; pred.acc #Prediction Accuracy
a<- diag(ctable)[2]/apply(ctable, 1, sum)[2] # Sensitivity
b<- diag(ctable)[1]/apply(ctable, 1, sum)[1] # Specificity

c[,i] <- matrix(c(miss.err, pred.acc, a, b ))
}
rownames(c)<- c("miss.err", "Acc", "Sen", "Spe")
c

#### LDA/QDA
plot

fit = lda(quality ~., data=red.train)
plot(fit)
fit = qda(quality ~., data=red.train)


### Prediction
d<-1
for(i in seq(0.1, 1, by=0.1)) {
cutoff = i
pred = predict(fit, newdata=red.test)$posterior
yhat = ifelse(pred[,2] > cutoff, 1, 0)
ctable = table(red.test$quality, yhat, dnn=c("Actual", "Predicted")); ctable #classification table


### Errors

miss.err = 1-sum(diag(ctable))/sum(ctable); miss.err # Misclassification Rate
pred.acc = 1 - miss.err; pred.acc #Prediction Accuracy
a<-diag(ctable)[2]/apply(ctable, 1, sum)[2] # Sensitivity
b<-diag(ctable)[1]/apply(ctable, 1, sum)[1] # Specificity
c[,d] <- matrix(c(miss.err, pred.acc, a, b ))
d<-d+1
}

c
### ROC and AUC

par(mfrow = c(2,2))

pred2 = predict(fit, newdata=red.train)$posterior
pred = prediction(pred2[,2], red.train$quality)
perf = performance(pred, "tpr","fpr")

plot(perf, col = 4, lwd = 2, xlab = "1-Specificity", ylab = "Sensitivity", main = "ROC Curve (Train)") #ROC
lines(x = c(0,1), y = c(0,1), col = 2, lty = 2, lwd = 2)
legend(0.5, 0.3, legend = c("QDA","Random"), col = c(4,2), lty = c(1,2), lwd = 2)

performance(pred, "auc")@y.values #AUC


pred2 = predict(fit, newdata=red.test)$posterior
pred = prediction(pred2[,2], red.test$quality)
perf = performance(pred, "tpr","fpr")

plot(perf, col = 4, lwd = 2, xlab = "1-Specificity", ylab = "Sensitivity", main = "ROC Curve (Test)") #ROC
lines(x = c(0,1), y = c(0,1), col = 2, lty = 2, lwd = 2)
legend(0.5, 0.3, legend = c("QDA","Random"), col = c(4,2), lty = c(1,2), lwd = 2)

performance(pred, "auc")@y.values #AUC


###################Regression

### Model fit

fit = glm(quality ~., data = red.train, family = binomial(link = "logit"))
summary(fit)


### Model selection

fit2 = step(fit, direction = "both")
fit2$anova
summary(fit2)


### Prediction

fit2.pred = predict(fit2, newdata =  red.test, type = "response") 

for(i in 1:10) {
cutoff = i/10
fit2.yhat = ifelse(fit2.pred <= cutoff, 0, 1)

ctable = table(red.test$quality, fit2.yhat,  dnn = c("Actual", "Predicted")) 

### Errors

miss.err = 1-sum(diag(ctable))/sum(ctable) # Misclassification Rate

pred.acc = 1 - miss.err #Prediction Accuracy

a<-diag(ctable)[2]/apply(ctable, 1, sum)[2] # Sensitivity
b<-diag(ctable)[1]/apply(ctable, 1, sum)[1] # Specificity

c[,i] <- matrix(c(miss.err, pred.acc, a, b ))
}
c
### ROC and AUC

par(mfrow = c(2,2))

fit.pred = predict(fit, newdata = red.train, type = "response") 
pred = prediction(fit.pred, red.train$quality)

perf = performance(pred, "tpr","fpr")
plot(perf, col = 4, lwd = 2, xlab = "1-Specificity", ylab = "Sensitivity", main = "ROC Curve (Train)") #ROC
lines(x = c(0,1), y = c(0,1), col = 2, lty = 2, lwd = 2)
legend(0.5, 0.3, legend = c("Regression","Random"), col = c(4,2), lty = c(1,2), lwd = 2)

performance(pred, "auc")@y.values #AUC


fit.pred = predict(fit, newdata = red.test, type = "response") 
pred = prediction(fit.pred, red.test$quality)

perf = performance(pred, "tpr","fpr")
plot(perf, col = 4, lwd = 2, xlab = "1-Specificity", ylab = "Sensitivity", main = "ROC Curve (Test)") #ROC
lines(x = c(0,1), y = c(0,1), col = 2, lty = 2, lwd = 2)
legend(0.5, 0.3, legend = c("Regression","Random"), col = c(4,2), lty = c(1,2), lwd = 2)

performance(pred, "auc")@y.values #AUC




##########################
# Computing the CV error


V = 10 #V-fold CV
miss.err.train = 0
miss.err.test = 0
cutoff = 0.5

set.seed(12345)
id = sample(1:V, nrow(red), replace = T)

##KNN
CK <- matrix(nrow=2, ncol=10)
for(a in 1:10) {
  miss.err.train = 0
  miss.err.test = 0
for(i in 1:V) {
  
  print(i)
  
  red.train = red[id != i,] 
  red.test = red[id == i,] 
  
  fit = knn(train=red.train[,-12],test=red.train[,-12],cl=red.train[,12], k=a) 
  yhat=fit
  miss.err.train = miss.err.train + mean(red.train[,12] != yhat) 
  
  fit = knn(train=red.train[,-12], test=red.test[,-12], cl=red.train[,12], k=a) 
  yhat=fit
  miss.err.test = miss.err.test + mean(red.test[,12] != yhat) 
}
  CK[1,a] <- miss.err.train/ V
  CK[2,a] <- miss.err.test/ V
  
}
cv.err.train = miss.err.train/ V; cv.err.train # CV training error
cv.err.test = miss.err.test/ V;cv.err.test # CV test error
rownames(CK) <- c("CV training error", "CV test error")
CK

##LDA/QDA

for(a in 1:10){
  miss.err.train = 0
  miss.err.test = 0
  for(i in 1:V) {
  
  print(i)
  
  red.train = red[id != i,] 
  red.test = red[id == i,] 
  
  #fit = lda(quality ~., data=red.train)
  fit = qda(quality ~., data=red.train)
  
  pred = predict(fit, newdata=red.train)$posterior
  yhat = ifelse(pred[,2] > a/10, 1, 0)
  miss.err.train = miss.err.train + mean(red.train$quality != yhat) 
  
  pred = predict(fit, newdata=red.test)$posterior
  yhat = ifelse(pred[,2] > a/10, 1, 0)
  miss.err.test = miss.err.test + mean(red.test$quality != yhat) 
  
}
  CK[1,a] <- miss.err.train/ V
  CK[2,a] <- miss.err.test/ V
}
CK
cv.err.train = miss.err.train/ V; cv.err.train # CV training error
cv.err.test = miss.err.test/ V;cv.err.test # CV test error

#Regression
for(a in 1: 10) {
  miss.err.train = 0
  miss.err.test = 0
for(i in 1:V) {
  
  print(i)
  
  red.train = red[id != i,] 
  red.test = red[id == i,] 
  
  fit = glm(quality ~ ., data = red.train, family = binomial(link = "logit"))
  fit2 = step(fit, direction="both", trace=FALSE) #Stepwise variable selection
  
  pred.train = predict(fit2, newdata=red.train, type="response")
  yhat.train = ifelse(pred.train <= a/10, 0, 1)
  miss.err.train = miss.err.train + mean(red.train$quality != yhat.train) 
  
  pred.test = predict(fit2, newdata=red.test, type="response")
  yhat.test = ifelse(pred.test<= a/10, 0, 1)
  miss.err.test = miss.err.test + mean(red.test$quality != yhat.test)
  
}
  CK[1,a] <- miss.err.train/ V
  CK[2,a] <- miss.err.test/ V
}
CK
cv.err.train = miss.err.train/ V # CV training error
cv.err.train

cv.err.test = miss.err.test/ V # CV test error
cv.err.test


### END
